# Asus-K501LB-Hackintosh

# Specs:
- Microprocessor: Intel® Core™ i5 5200U
- Video graphics: Intel® HD Graphics 5500
- DGPU: NVIDIA® GeForce® 940M 2GB DDR3
- Display: 15.6" 16:9 Full HD (1920x1080)
- Camera: VGA Web Camera
- Network interface: 802.11 b/g/n 

# Working:
- Restart and Shutdown
- CPU Power Management
- Ethenet 
- Audio 
- Brightness key
- Volumes key
- Touchpad
- HDMI Port
- All USB Ports

# Not Working:
- Airdrop
- SDcard port
- Wifi, Bluetooth, Handoff
- NVIDIA® GeForce® 940M 
